
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_csv("retail_data.csv")

correlation = df['Inventory_Days'].corr(df['Profit'])
print("Correlation:", correlation)
