
SELECT 
    category,
    ROUND(SUM(sales),2) AS total_sales,
    ROUND(SUM(profit),2) AS total_profit,
    ROUND((SUM(profit) / SUM(sales)) * 100,2) AS profit_margin
FROM retail_data
GROUP BY category
ORDER BY profit_margin ASC;
